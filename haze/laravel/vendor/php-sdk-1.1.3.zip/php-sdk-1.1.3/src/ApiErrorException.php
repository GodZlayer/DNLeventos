<?php

namespace OpenPix\PhpSdk;

use Exception;

class ApiErrorException extends Exception
{
}
